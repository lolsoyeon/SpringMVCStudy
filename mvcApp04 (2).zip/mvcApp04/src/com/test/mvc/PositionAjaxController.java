/*
	- #46.PositionAjaxController.java
	- 사용자 정의 컨트롤러 클래스
	- DAO 객체 의존성 주입
*/

package com.test.mvc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

// ※ Spring이 제공하는 『Controller』 인터페이스를 구현함으로써
//	  사용자 정의 컨트롤러 클래스를 구성한다.

public class PositionAjaxController implements Controller
{
	private IPositionDAO dao;
	

	public void setDao(IPositionDAO dao)
	{
		this.dao = dao;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		// 컨트롤러 내부 액션 처리 코드
		
		ModelAndView mav = new ModelAndView();
		
		// 세션 처리 과정 추가(로그인에 대한 확인 과정 추가) ------------------------------------
		HttpSession session = request.getSession();
		
		if (session.getAttribute("name")==null)
		{
			mav.setViewName("redirect:loginform.action");
			return mav;
		}
		else if (session.getAttribute("admin")==null)
		{
			mav.setViewName("redirect:logout.action");
			return mav;
		}
		
		// ------------------------------------- 세션 처리 과정 추가(로그인에 대한 확인 과정 추가)
		
		
		// 이전페이지(PositionInsertForm.jsp)로 부터 데이터 수신
		//- positionName
		String positionName = request.getParameter("positionName");
		
		ArrayList<Position> positionList = new ArrayList<Position>();
		
		String str = "";
		try
		{
			positionList = dao.list();
			
			for (Position position : positionList)
			{
				if (position.getPositionName().equals(positionName))	// 이미 있는이름
				{
					str = "이미 사용중인 이름이 존재합니다.";
					break;
				}
				else 
				{
					str = "사용할 수 있는 이름입니다.";
				}
			}
			
			mav.addObject("reuslt", str);
			mav.setViewName("PositionAjax");
			
					
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return mav;
	}
	
}
