/*
  - #48.DepartmentListController.java
	- 사용자 정의 컨트롤러 클래스
	- 부서 페이지 요청 처리 담당 클래스
	- DAO 객체 의존성 주입
*/

package com.test.mvc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

// ※ Spring이 제공하는 『Controller』 인터페이스를 구현함으로써
//	  사용자 정의 컨트롤러 클래스를 구성한다.

public class DepartmentListController implements Controller
{
	// 인터페이스 형태의 자료형 멤버 구성
	private IDepartmentDAO dao;
	
	// setter 메소드 구성
	public void setDao(IDepartmentDAO dao)
	{
		this.dao = dao;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		// 컨트롤러 내부 액션 처리 코드
		
		ModelAndView mav = new ModelAndView();
		
		// 세션 처리 과정 추가(로그인에 대한 확인 과정 추가) ------------------------------------
		HttpSession session = request.getSession();
		
		if (session.getAttribute("name")==null)
		{
			// 로그인이 되어 있지 않은 상황에서의 처리
			// -- 로그인 폼 페이지를 요청할 수 있도록 안내
			mav.setViewName("redirect:loginform.action");
			return mav;
		}
		else if (session.getAttribute("admin")==null)
		{
			// 로그인은 되어 있으나 관리자가 아닌 상황에서의 처리
			// 일반 사원일 때의 처리
			// -- 일반 사원으로 로그인되어 있는 상황을 해제하고
			//	  다시 관리자로 로그인할 수 있도록 처리
			mav.setViewName("redirect:logout.action");
			return mav;
		}
		
		// ------------------------------------- 세션 처리 과정 추가(로그인에 대한 확인 과정 추가)
		
		// 부서 리스트들 불러오기
		ArrayList<Department> departmentList = new ArrayList<Department>();
		
		try
		{
			departmentList = dao.list();
			
			mav.addObject("departmentList", departmentList);
			
			mav.setViewName("DepartmentList");
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		
		
		
		
		
		return mav;
	}
	
}
