/*
- #55. PositionUpdateFormController.java
	- 사용자 정의 컨트롤러 클래스
*/

package com.test.mvc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class PositionUpdateFormController implements Controller
{
	private IPositionDAO dao;
	
	public void setDao(IPositionDAO dao)
	{
		this.dao = dao;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		// 컨트롤러 내부 액션 처리 코드
		
		ModelAndView mav = new ModelAndView();
		
		// 세션 처리 과정 추가(로그인에 대한 확인 과정 추가) ------------------------------------
		
		HttpSession session = request.getSession();
		
		if (session.getAttribute("name")==null)
		{
			mav.setViewName("redirect:loginform.action");
			return mav;
			
		} else if (session.getAttribute("admin")==null)
		{
			mav.setViewName("redirect:logout.action");
			return mav;
			
		}
		
		// ------------------------------------ 세션 처리 과정 추가(로그인에 대한 확인 과정 추가)
		// 이전 페이지(PositionList.jsp)로 부터 데이터 수신
		//-- positionId
		
		String positionId = request.getParameter("positionId");
		
		String positionName = "";
		int positionPay = 0;
		
		ArrayList<Position> positionList = new ArrayList<Position>();
		try
		{
//			Position position = new Position();
			
			positionList = dao.list();
			
			for (Position position : positionList)
			{
				if (position.getPositionId().equals(positionId))
				{
					positionName = position.getPositionName();
					positionPay = position.getMinBasicPay();
				}
			}
			
			mav.addObject("positionId", positionId);
			mav.addObject("positionName", positionName);
			mav.addObject("positionPay", positionPay);
			
			mav.setViewName("PositionUpdateForm");
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		
		return mav;
	}
	
}
