/*
	- #38. RegionAjaxController.java
	- 사용자 정의 컨트롤러 클래스
	- 지역 리스트의 지역명 중복검사 결과 반환 액션
*/

package com.test.mvc;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

// ※ Spring이 제공하는 『Controller』 인터페이스를 구현함으로써
//	  사용자 정의 컨트롤러 클래스를 구성한다.

public class RegionAjaxController implements Controller
{
	private IRegionDAO dao;
	
	public void setDao(IRegionDAO dao)
	{
		this.dao = dao;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		// 컨트롤러 내부 액션 처리 코드
		
		ModelAndView mav = new ModelAndView();
		
		// 이전 페이지(RegionInsertForm.jsp)로부터 데이터 수신
		//-- regionName
		String regionName = request.getParameter("regionName");
		
		ArrayList<Region> regionList = new ArrayList<Region>();
		
		String str = "";
		
		try
		{
			regionList = dao.list();
			
			for (Region region : regionList)
			{
				if (region.getRegionName().equals(regionName))
				{
					str = "이미 사용중인 이름이 존재합니다.";
					break;
				} 
				else
				{
					str = "사용할 수 있는 이름입니다.";
				}
			}
			mav.addObject("result", str);
			
			mav.setViewName("RegionAjax");
			
		} catch (Exception e)
		{
			System.out.println(e.toString());
		}
		
		return mav;
	}
	
}
